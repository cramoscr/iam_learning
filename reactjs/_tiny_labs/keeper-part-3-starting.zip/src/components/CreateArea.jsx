import React, { useState } from "react";

function CreateArea(props) {
  const [noteEntry, setNoteEntry] = useState({
    key: "",
    title: "",
    content: ""
  });

  function handleChange(event) {
    // This is called JS "destructuring" (split complex datastructure into a simple fields)
    const { name, value } = event.target;

    // Highly elevated science here !!!
    setNoteEntry((prevValue) => {
      if (name === "nTitle") {
        return {
          title: value,
          content: prevValue.content
        };
      } else if (name === "nContent") {
        return {
          title: prevValue.title,
          content: value
        };
      }
    });
  }

  return (
    <div>
      <form onSubmit={props.mySubmit}>
        <input
          name="nTitle"
          value={noteEntry.title}
          placeholder="Title here..."
          onChange={handleChange}
        />
        <textarea
          name="nContent"
          value={noteEntry.content}
          placeholder="Content here..."
          onChange={handleChange}
        />
        <button
          onClick={() => {
            props.onAdd(noteEntry);
            //Reset the input fields
            setNoteEntry({
              key: "",
              title: "",
              content: ""
            });
          }}
        >
          <span>Add</span>
        </button>
      </form>
    </div>
  );
}

export default CreateArea;
