import React, { useState } from "react";
import Header from "./Header";
import Footer from "./Footer";
import Note from "./Note";
import CreateArea from "./CreateArea";

function App() {
  const [notes, setNotes] = useState([
    {
      key: 0,
      title: "First note",
      content: "This is the content"
    }
  ]);

  // Tricky things:
  // a. It's better to keep this function here instead of the
  //    InputArea because the data array is totally handled here
  // b. The use of "inputText" as a parameter is tricky because
  //    it will not be used directly here, instead it will be
  //    filled inside InputArea component
  function addNote(newNote) {
    setNotes((prevItems) => {
      return [...prevItems, newNote];
    });
  }

  // It's better to keep this function here (instead of the CreateArea)
  // because the data array maintenance is done here
  function deleteNote(id) {
    setNotes((prevItems) => {
      return prevItems.filter((item, index) => {
        return index !== id;
      });
    });
  }

  // This avoid default reloading after submit button pressed
  function handleSubmit(event) {
    event.preventDefault();
  }

  return (
    <div>
      <Header />
      <CreateArea onAdd={addNote} mySubmit={handleSubmit} />
      {notes.map((entry, index) => {
        return (
          <Note
            id={index}
            key={index}
            onRemoval={deleteNote}
            title={entry.title}
            content={entry.content}
          />
        );
      })}
      <Footer />
    </div>
  );
}

export default App;
