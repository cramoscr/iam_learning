import React, { useState } from "react";
import Note from "./Note.jsx";

function App() {
  const [inputData, setNote] = useState("");
  const [items, addNote] = useState([]);

  function handleChange(event) {
    //console.log("handleChange: " + event.target.value);
    const newValue = event.target.value;
    setNote(newValue);
  }
  function handleSubmit() {
    //console.log("handleSubmit... itemData: " + inputData);
    addNote((prevItems) => {
      return [...prevItems, inputData];
    });
  }

  return (
    <div className="container">
      <div className="heading">
        <h1>To-Do List</h1>
      </div>
      <div className="form">
        <input onChange={handleChange} type="text" value={inputData} />
        <button onClick={handleSubmit}>
          <span>Add</span>
        </button>
      </div>
      <div>
        <ul>
          {items.map((item_entry) => {
            return <li>{item_entry}</li>;
          })}
          ;
        </ul>
      </div>
    </div>
  );
}

export default App;
